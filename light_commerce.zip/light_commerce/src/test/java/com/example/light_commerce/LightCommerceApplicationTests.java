package com.example.light_commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightCommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
