package com.example.light_commerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LightCommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LightCommerceApplication.class, args);
	}

}
